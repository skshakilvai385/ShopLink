import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Grid, 
  List, 
  Star, 
  Heart, 
  ShoppingCart,
  Plus,
  TrendingUp,
  Award,
  Truck,
  Shield,
  Eye,
  Share2,
  MapPin,
  Clock,
  Zap,
  Tag,
  Users,
  ChevronDown,
  SlidersHorizontal,
  Bookmark,
  MessageCircle,
  ArrowRight
} from 'lucide-react';

export default function Marketplace() {
  const [viewMode, setViewMode] = useState('grid');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('featured');
  const [priceRange, setPriceRange] = useState([0, 2000]);

  const categories = [
    { id: 'all', name: 'All Items', count: 1250, icon: Grid, color: 'from-blue-500 to-indigo-500' },
    { id: 'electronics', name: 'Electronics', count: 320, icon: Zap, color: 'from-purple-500 to-pink-500' },
    { id: 'fashion', name: 'Fashion', count: 450, icon: Heart, color: 'from-green-500 to-emerald-500' },
    { id: 'home', name: 'Home & Garden', count: 280, icon: Award, color: 'from-orange-500 to-red-500' },
    { id: 'sports', name: 'Sports & Fitness', count: 200, icon: TrendingUp, color: 'from-cyan-500 to-blue-500' }
  ];

  const products = [
    {
      id: 1,
      name: 'iPhone 15 Pro Max 256GB',
      price: 1199,
      originalPrice: 1299,
      rating: 4.8,
      reviews: 324,
      image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      seller: 'TechStore Pro',
      badge: 'Trending',
      discount: 8,
      shipping: 'Free',
      verified: true,
      location: '2.3 km away',
      inStock: true,
      fastDelivery: true,
      category: 'electronics'
    },
    {
      id: 2,
      name: 'Nike Air Max 270 React',
      price: 150,
      originalPrice: 180,
      rating: 4.6,
      reviews: 156,
      image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      seller: 'SportZone Official',
      badge: 'Best Seller',
      discount: 17,
      shipping: 'Free',
      verified: true,
      location: '1.8 km away',
      inStock: true,
      fastDelivery: true,
      category: 'sports'
    },
    {
      id: 3,
      name: 'MacBook Pro 16" M3 Chip',
      price: 2399,
      originalPrice: 2499,
      rating: 4.9,
      reviews: 89,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      seller: 'Apple Authorized',
      badge: 'New',
      discount: 4,
      shipping: 'Free',
      verified: true,
      location: '0.5 km away',
      inStock: true,
      fastDelivery: true,
      category: 'electronics'
    },
    {
      id: 4,
      name: 'Sony WH-1000XM5 Headphones',
      price: 299,
      originalPrice: 399,
      rating: 4.7,
      reviews: 234,
      image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      seller: 'AudioTech Hub',
      badge: 'Deal',
      discount: 25,
      shipping: '$5.99',
      verified: false,
      location: '3.2 km away',
      inStock: true,
      fastDelivery: false,
      category: 'electronics'
    },
    {
      id: 5,
      name: 'Apple Watch Series 9 GPS',
      price: 399,
      originalPrice: 449,
      rating: 4.5,
      reviews: 167,
      image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      seller: 'WearableTech',
      badge: 'Popular',
      discount: 11,
      shipping: 'Free',
      verified: true,
      location: '1.2 km away',
      inStock: true,
      fastDelivery: true,
      category: 'electronics'
    },
    {
      id: 6,
      name: 'Herman Miller Gaming Chair',
      price: 249,
      originalPrice: 329,
      rating: 4.4,
      reviews: 98,
      image: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      seller: 'GameSetup Pro',
      badge: 'Sale',
      discount: 24,
      shipping: 'Free',
      verified: true,
      location: '4.1 km away',
      inStock: true,
      fastDelivery: false,
      category: 'home'
    }
  ];

  const featuredStores = [
    {
      id: 1,
      name: 'TechStore Pro',
      rating: 4.9,
      products: 1250,
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
      verified: true,
      badge: 'Top Seller'
    },
    {
      id: 2,
      name: 'Fashion Hub',
      rating: 4.7,
      products: 890,
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
      verified: true,
      badge: 'Trending'
    }
  ];

  const getBadgeColor = (badge) => {
    switch (badge) {
      case 'Trending': return 'bg-gradient-to-r from-red-500 to-pink-500';
      case 'Best Seller': return 'bg-gradient-to-r from-green-500 to-emerald-500';
      case 'New': return 'bg-gradient-to-r from-blue-500 to-indigo-500';
      case 'Deal': return 'bg-gradient-to-r from-orange-500 to-red-500';
      case 'Popular': return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'Sale': return 'bg-gradient-to-r from-pink-500 to-rose-500';
      default: return 'bg-gradient-to-r from-gray-500 to-gray-600';
    }
  };

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Enhanced Header */}
      <div className="bg-white/90 backdrop-blur-xl border-b border-gray-200/50 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            {/* Enhanced Search */}
            <div className="flex-1 max-w-2xl">
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-blue-500 transition-colors" />
                <input
                  type="text"
                  placeholder="Search products, brands, or categories..."
                  className="w-full pl-12 pr-6 py-4 bg-gray-50/80 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all duration-200 text-sm"
                />
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                  <kbd className="px-2 py-1 text-xs text-gray-500 bg-gray-200 rounded-md">⌘K</kbd>
                </div>
              </div>
            </div>

            {/* Enhanced Actions */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-gray-100 rounded-2xl p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-3 rounded-xl transition-all duration-200 ${
                    viewMode === 'grid' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-3 rounded-xl transition-all duration-200 ${
                    viewMode === 'list' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
              
              <button className="flex items-center space-x-2 px-6 py-3 border border-gray-300 rounded-2xl hover:bg-gray-50 transition-all duration-200 bg-white">
                <SlidersHorizontal className="w-4 h-4" />
                <span className="font-medium">Filters</span>
              </button>

              <button className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-2xl hover:shadow-lg transition-all duration-200 flex items-center space-x-2 font-medium">
                <Plus className="w-4 h-4" />
                <span>Sell Item</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Enhanced Sidebar */}
          <aside className="lg:w-80">
            {/* Categories */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6 mb-6">
              <h3 className="font-bold text-gray-900 mb-6 text-lg">Categories</h3>
              <div className="space-y-3">
                {categories.map((category) => {
                  const Icon = category.icon;
                  const isActive = selectedCategory === category.id;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full flex items-center space-x-4 px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
                        isActive
                          ? `bg-gradient-to-r ${category.color} text-white shadow-lg`
                          : 'text-gray-600 hover:bg-gray-50 hover:text-blue-600'
                      }`}
                    >
                      <div className={`p-2 rounded-lg transition-all duration-200 ${
                        isActive ? 'bg-white/20' : 'bg-gray-100 group-hover:bg-blue-100'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <span className="font-medium">{category.name}</span>
                        <p className={`text-xs mt-0.5 ${isActive ? 'text-white/80' : 'text-gray-500'}`}>
                          {category.count} items
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price Range */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6 mb-6">
              <h3 className="font-bold text-gray-900 mb-4">Price Range</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">$0</span>
                  <span className="text-sm text-gray-600">$2000+</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="2000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex items-center justify-between">
                  <input
                    type="number"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    placeholder="Min"
                  />
                  <span className="text-gray-400">to</span>
                  <input
                    type="number"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    placeholder="Max"
                  />
                </div>
              </div>
            </div>

            {/* Featured Stores */}
            <div className="bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl p-6 text-white mb-6">
              <div className="flex items-center space-x-3 mb-4">
                <Award className="w-6 h-6" />
                <span className="font-bold">Featured Stores</span>
              </div>
              <div className="space-y-3">
                {featuredStores.map((store) => (
                  <div key={store.id} className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                    <div className="flex items-center space-x-3">
                      <img
                        src={store.image}
                        alt={store.name}
                        className="w-12 h-12 rounded-xl object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-semibold">{store.name}</h4>
                          {store.verified && (
                            <Shield className="w-3 h-3" />
                          )}
                        </div>
                        <div className="flex items-center space-x-2 text-sm text-blue-100">
                          <Star className="w-3 h-3 fill-current" />
                          <span>{store.rating}</span>
                          <span>•</span>
                          <span>{store.products} products</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full bg-white text-blue-600 px-4 py-3 rounded-xl font-semibold hover:bg-blue-50 transition-colors mt-4">
                View All Stores
              </button>
            </div>
          </aside>

          {/* Enhanced Main Content */}
          <main className="flex-1">
            {/* Stats and Sort Bar */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-6">
                <span className="text-gray-600">
                  Showing <span className="font-semibold text-gray-900">1-6</span> of <span className="font-semibold text-gray-900">{filteredProducts.length}</span> products
                </span>
                <div className="flex items-center space-x-2">
                  <Tag className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-green-600 font-medium">Best deals available</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                >
                  <option value="featured">Sort by: Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="newest">Newest First</option>
                  <option value="rating">Best Rating</option>
                  <option value="popular">Most Popular</option>
                </select>
              </div>
            </div>

            {/* Enhanced Products Grid */}
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' 
                : 'grid-cols-1'
            }`}>
              {filteredProducts.map((product) => (
                <div key={product.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 overflow-hidden hover:shadow-xl transition-all duration-300 group hover:scale-105">
                  {/* Product Image */}
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    
                    {/* Badges */}
                    <div className="absolute top-4 left-4 flex flex-col space-y-2">
                      <div className={`${getBadgeColor(product.badge)} text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg`}>
                        {product.badge}
                      </div>
                      {product.discount > 0 && (
                        <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg">
                          -{product.discount}% OFF
                        </div>
                      )}
                    </div>

                    {/* Quick Actions */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-3">
                      <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg">
                        <Eye className="w-5 h-5" />
                      </button>
                      <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg">
                        <Heart className="w-5 h-5" />
                      </button>
                      <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg">
                        <Share2 className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Status Indicators */}
                    <div className="absolute top-4 right-4 flex flex-col space-y-2">
                      {product.fastDelivery && (
                        <div className="bg-green-500 text-white p-2 rounded-full shadow-lg">
                          <Zap className="w-3 h-3" />
                        </div>
                      )}
                      {product.verified && (
                        <div className="bg-blue-500 text-white p-2 rounded-full shadow-lg">
                          <Shield className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Enhanced Product Info */}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-bold text-gray-900 line-clamp-2 text-lg">{product.name}</h3>
                      <button className="text-gray-400 hover:text-red-500 transition-colors">
                        <Heart className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Rating and Reviews */}
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-semibold text-gray-900">{product.rating}</span>
                      </div>
                      <span className="text-sm text-gray-500">({product.reviews} reviews)</span>
                      <div className="flex items-center space-x-1">
                        <Users className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-500">234 sold</span>
                      </div>
                    </div>

                    {/* Seller Info */}
                    <div className="flex items-center space-x-2 mb-4">
                      <span className="text-sm text-gray-600">by</span>
                      <span className="text-sm font-semibold text-blue-600 hover:text-blue-700 cursor-pointer">
                        {product.seller}
                      </span>
                      {product.verified && (
                        <Shield className="w-3 h-3 text-green-500" />
                      )}
                    </div>

                    {/* Location and Delivery */}
                    <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3" />
                        <span>{product.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Truck className="w-3 h-3" />
                        <span>{product.shipping === 'Free' ? 'Free delivery' : `Delivery: ${product.shipping}`}</span>
                      </div>
                    </div>

                    {/* Price */}
                    <div className="flex items-center space-x-3 mb-6">
                      <span className="text-3xl font-bold text-gray-900">${product.price}</span>
                      {product.originalPrice > product.price && (
                        <span className="text-lg text-gray-500 line-through">${product.originalPrice}</span>
                      )}
                      {product.discount > 0 && (
                        <span className="bg-green-100 text-green-600 px-2 py-1 rounded-full text-xs font-semibold">
                          Save ${product.originalPrice - product.price}
                        </span>
                      )}
                    </div>

                    {/* Stock Status */}
                    <div className="flex items-center space-x-2 mb-4">
                      <div className={`w-2 h-2 rounded-full ${product.inStock ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      <span className={`text-sm font-medium ${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                        {product.inStock ? 'In Stock' : 'Out of Stock'}
                      </span>
                      {product.fastDelivery && (
                        <>
                          <span className="text-gray-300">•</span>
                          <span className="text-sm text-blue-600 font-medium">Fast Delivery</span>
                        </>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex space-x-3">
                      <button className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-4 rounded-xl hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2 font-semibold">
                        <ShoppingCart className="w-4 h-4" />
                        <span>Add to Cart</span>
                      </button>
                      <button className="border border-gray-300 text-gray-700 py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                      </button>
                      <button className="border border-gray-300 text-gray-700 py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors">
                        <Bookmark className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Enhanced Load More */}
            <div className="text-center mt-12">
              <button className="bg-white border border-gray-300 text-gray-700 px-8 py-4 rounded-2xl hover:bg-gray-50 transition-all duration-200 flex items-center space-x-3 mx-auto shadow-sm hover:shadow-md">
                <span className="font-medium">Load More Products</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}