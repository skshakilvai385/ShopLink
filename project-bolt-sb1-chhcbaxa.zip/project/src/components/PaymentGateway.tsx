import React, { useState } from 'react';
import { 
  CreditCard, 
  Send, 
  Download, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft,
  Wallet,
  Smartphone,
  Globe,
  Shield,
  Clock,
  CheckCircle,
  TrendingUp,
  Eye,
  EyeOff,
  QrCode,
  Users,
  Zap,
  Star,
  Award,
  Target,
  PiggyBank,
  Receipt,
  History,
  Settings,
  Bell,
  Lock,
  Fingerprint
} from 'lucide-react';

export default function PaymentGateway() {
  const [showBalance, setShowBalance] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  const quickActions = [
    { 
      icon: Send, 
      label: 'Send Money', 
      color: 'from-blue-500 to-blue-600',
      description: 'Transfer instantly',
      shortcut: '⌘S'
    },
    { 
      icon: Download, 
      label: 'Request', 
      color: 'from-green-500 to-green-600',
      description: 'Request payment',
      shortcut: '⌘R'
    },
    { 
      icon: Plus, 
      label: 'Add Money', 
      color: 'from-purple-500 to-purple-600',
      description: 'Top up wallet',
      shortcut: '⌘A'
    },
    { 
      icon: QrCode, 
      label: 'QR Pay', 
      color: 'from-orange-500 to-orange-600',
      description: 'Scan & pay',
      shortcut: '⌘Q'
    }
  ];

  const recentTransactions = [
    {
      id: 1,
      type: 'sent',
      recipient: 'Sarah Johnson',
      amount: 45.00,
      time: '2 min ago',
      status: 'completed',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      category: 'personal',
      description: 'Coffee meetup'
    },
    {
      id: 2,
      type: 'received',
      recipient: 'John Smith',
      amount: 120.00,
      time: '1 hour ago',
      status: 'completed',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      category: 'business',
      description: 'Freelance payment'
    },
    {
      id: 3,
      type: 'sent',
      recipient: 'Netflix',
      amount: 15.99,
      time: '2 days ago',
      status: 'completed',
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      category: 'subscription',
      description: 'Monthly subscription'
    },
    {
      id: 4,
      type: 'received',
      recipient: 'TechCorp Ltd',
      amount: 850.00,
      time: '3 days ago',
      status: 'completed',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      category: 'business',
      description: 'Project milestone'
    },
    {
      id: 5,
      type: 'sent',
      recipient: 'Amazon',
      amount: 67.99,
      time: '4 days ago',
      status: 'completed',
      avatar: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      category: 'shopping',
      description: 'Online purchase'
    }
  ];

  const paymentMethods = [
    {
      id: 1,
      type: 'card',
      name: 'Visa •••• 4532',
      expiry: '12/26',
      isDefault: true,
      icon: CreditCard,
      color: 'from-blue-500 to-indigo-500'
    },
    {
      id: 2,
      type: 'bank',
      name: 'Chase Bank •••• 8901',
      expiry: 'Checking',
      isDefault: false,
      icon: Wallet,
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 3,
      type: 'digital',
      name: 'PayPal Account',
      expiry: 'john@example.com',
      isDefault: false,
      icon: Smartphone,
      color: 'from-purple-500 to-pink-500'
    }
  ];

  const stats = [
    { 
      label: 'Total Spent', 
      value: '$2,847.50', 
      change: '+12.5%', 
      trend: 'up',
      icon: ArrowUpRight,
      color: 'from-red-500 to-pink-500'
    },
    { 
      label: 'Total Received', 
      value: '$4,230.00', 
      change: '+8.2%', 
      trend: 'up',
      icon: ArrowDownLeft,
      color: 'from-green-500 to-emerald-500'
    },
    { 
      label: 'Transactions', 
      value: '156', 
      change: '+23.1%', 
      trend: 'up',
      icon: Receipt,
      color: 'from-blue-500 to-indigo-500'
    },
    { 
      label: 'Saved', 
      value: '$1,382.50', 
      change: '+15.7%', 
      trend: 'up',
      icon: PiggyBank,
      color: 'from-purple-500 to-pink-500'
    }
  ];

  const quickContacts = [
    {
      id: 1,
      name: 'Sarah',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      lastAmount: '$45'
    },
    {
      id: 2,
      name: 'John',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      lastAmount: '$120'
    },
    {
      id: 3,
      name: 'Alex',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      lastAmount: '$25'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Enhanced Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Digital Wallet</h1>
              <p className="text-gray-600">Manage your money with confidence and security</p>
            </div>
            <div className="flex items-center space-x-3">
              <button className="p-3 bg-white rounded-2xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200">
                <Bell className="w-5 h-5 text-gray-600" />
              </button>
              <button className="p-3 bg-white rounded-2xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200">
                <Settings className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        {/* Enhanced Balance Card */}
        <div className="relative bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-3xl p-8 text-white mb-8 overflow-hidden shadow-2xl">
          {/* Animated Background Elements */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-20 translate-x-20 animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-16 -translate-x-16 animate-bounce"></div>
          <div className="absolute top-1/2 right-1/4 w-24 h-24 bg-cyan-400/15 rounded-full animate-ping"></div>
          
          <div className="relative">
            <div className="flex items-center justify-between mb-8">
              <div>
                <div className="flex items-center space-x-3 mb-3">
                  <Wallet className="w-6 h-6 text-blue-200" />
                  <p className="text-blue-100 font-medium">Total Balance</p>
                </div>
                <div className="flex items-center space-x-4">
                  <h2 className="text-5xl font-bold">
                    {showBalance ? '$12,847.50' : '••••••••'}
                  </h2>
                  <button
                    onClick={() => setShowBalance(!showBalance)}
                    className="text-blue-200 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-xl"
                  >
                    {showBalance ? <EyeOff className="w-6 h-6" /> : <Eye className="w-6 h-6" />}
                  </button>
                </div>
              </div>
              <div className="text-right">
                <p className="text-blue-100 mb-2 font-medium">This Month</p>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-green-300" />
                  <p className="text-3xl font-bold text-green-300">+$1,247</p>
                </div>
                <p className="text-blue-200 text-sm">+12.5% increase</p>
              </div>
            </div>

            {/* Enhanced Quick Actions */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <button
                    key={index}
                    className="bg-white/15 backdrop-blur-sm rounded-2xl p-5 hover:bg-white/25 transition-all duration-300 group hover:scale-105"
                  >
                    <div className={`w-12 h-12 bg-gradient-to-r ${action.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-left">
                      <p className="font-semibold mb-1">{action.label}</p>
                      <p className="text-blue-200 text-sm">{action.description}</p>
                      <p className="text-blue-300 text-xs mt-1">{action.shortcut}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Enhanced Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-sm border border-gray-200/50 hover:shadow-lg transition-all duration-300 group">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <TrendingUp className={`w-5 h-5 ${stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}`} />
                </div>
                <p className="text-sm text-gray-600 mb-1 font-medium">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</p>
                <p className={`text-sm font-medium ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.change} from last month
                </p>
              </div>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Enhanced Recent Transactions */}
          <div className="lg:col-span-2">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50">
              <div className="p-6 border-b border-gray-200/50">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">Recent Transactions</h3>
                    <p className="text-gray-600 mt-1">Your latest financial activity</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="text-blue-600 hover:text-blue-700 font-medium flex items-center space-x-1">
                      <History className="w-4 h-4" />
                      <span>View All</span>
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="divide-y divide-gray-100/50">
                {recentTransactions.map((transaction) => (
                  <div key={transaction.id} className="p-6 hover:bg-gray-50/50 transition-colors group">
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <img
                          src={transaction.avatar}
                          alt={transaction.recipient}
                          className="w-14 h-14 rounded-2xl object-cover shadow-sm"
                        />
                        <div className={`absolute -bottom-1 -right-1 w-7 h-7 rounded-xl flex items-center justify-center shadow-sm ${
                          transaction.type === 'sent' ? 'bg-red-100' : 'bg-green-100'
                        }`}>
                          {transaction.type === 'sent' ? (
                            <ArrowUpRight className="w-4 h-4 text-red-600" />
                          ) : (
                            <ArrowDownLeft className="w-4 h-4 text-green-600" />
                          )}
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                              {transaction.recipient}
                            </p>
                            <p className="text-sm text-gray-600">{transaction.description}</p>
                            <div className="flex items-center space-x-2 mt-1">
                              <Clock className="w-3 h-3 text-gray-400" />
                              <span className="text-xs text-gray-500">{transaction.time}</span>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                transaction.status === 'completed' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'
                              }`}>
                                {transaction.status}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`text-xl font-bold ${
                              transaction.type === 'sent' ? 'text-red-600' : 'text-green-600'
                            }`}>
                              {transaction.type === 'sent' ? '-' : '+'}${transaction.amount.toFixed(2)}
                            </p>
                            <div className="flex items-center justify-end space-x-1 mt-1">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span className="text-xs text-green-600 font-medium">Verified</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Enhanced Sidebar */}
          <div className="space-y-6">
            {/* Payment Methods */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-gray-900 text-lg">Payment Methods</h3>
                <button className="text-blue-600 hover:text-blue-700 p-2 hover:bg-blue-50 rounded-xl transition-colors">
                  <Plus className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                {paymentMethods.map((method) => {
                  const Icon = method.icon;
                  return (
                    <div key={method.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-2xl hover:border-blue-300 transition-all duration-200 cursor-pointer group hover:shadow-sm">
                      <div className={`w-12 h-12 bg-gradient-to-r ${method.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{method.name}</p>
                        <p className="text-sm text-gray-500">{method.expiry}</p>
                      </div>
                      {method.isDefault && (
                        <span className="bg-blue-100 text-blue-600 text-xs px-3 py-1 rounded-full font-medium">
                          Default
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Send */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6">
              <h3 className="font-bold text-gray-900 mb-6 text-lg">Quick Send</h3>
              <div className="flex space-x-3 mb-6">
                {quickContacts.map((contact) => (
                  <button key={contact.id} className="flex flex-col items-center space-y-2 p-3 hover:bg-gray-50 rounded-2xl transition-colors group">
                    <img 
                      src={contact.avatar} 
                      alt={contact.name} 
                      className="w-12 h-12 rounded-2xl object-cover group-hover:scale-110 transition-transform shadow-sm" 
                    />
                    <span className="text-xs font-medium text-gray-700">{contact.name}</span>
                    <span className="text-xs text-gray-500">{contact.lastAmount}</span>
                  </button>
                ))}
                <button className="flex flex-col items-center space-y-2 p-3 hover:bg-gray-50 rounded-2xl transition-colors group">
                  <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                    <Users className="w-5 h-5 text-gray-600 group-hover:text-blue-600" />
                  </div>
                  <span className="text-xs font-medium text-gray-700">More</span>
                </button>
              </div>
              <button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-2xl hover:shadow-lg transition-all duration-200 font-semibold">
                Send Money
              </button>
            </div>

            {/* Enhanced Security */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-green-800 text-lg">Security Status</h3>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-700 font-medium">Two-Factor Auth</span>
                  </div>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Fingerprint className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-700 font-medium">Biometric Lock</span>
                  </div>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-700 font-medium">Fraud Protection</span>
                  </div>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
              </div>
              <div className="mt-6 p-4 bg-white/50 rounded-xl">
                <div className="flex items-center space-x-2 mb-2">
                  <Award className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-semibold text-green-800">Bank-Level Security</span>
                </div>
                <p className="text-xs text-green-700 leading-relaxed">
                  Your transactions are protected with 256-bit SSL encryption and real-time fraud monitoring.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}