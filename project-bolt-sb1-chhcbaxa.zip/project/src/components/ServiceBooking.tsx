import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Star, 
  Filter,
  Search,
  Car,
  Home,
  Wrench,
  Scissors,
  Truck,
  Users,
  CheckCircle,
  ArrowRight,
  Phone,
  MessageCircle,
  Heart,
  Shield,
  Award,
  Zap,
  Camera,
  Utensils,
  Dumbbell,
  Laptop,
  ChevronDown,
  Grid3X3,
  List,
  SlidersHorizontal,
  Bookmark,
  Share2,
  Eye
} from 'lucide-react';

export default function ServiceBooking() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [viewMode, setViewMode] = useState('grid');

  const categories = [
    { id: 'all', name: 'All Services', icon: Users, count: 150, color: 'from-blue-500 to-indigo-500' },
    { id: 'automotive', name: 'Automotive', icon: Car, count: 25, color: 'from-purple-500 to-pink-500' },
    { id: 'home', name: 'Home Services', icon: Home, count: 45, color: 'from-green-500 to-emerald-500' },
    { id: 'repair', name: 'Repair & Fix', icon: Wrench, count: 30, color: 'from-orange-500 to-red-500' },
    { id: 'beauty', name: 'Beauty & Spa', icon: Scissors, count: 20, color: 'from-pink-500 to-rose-500' },
    { id: 'delivery', name: 'Delivery', icon: Truck, count: 30, color: 'from-cyan-500 to-blue-500' },
    { id: 'fitness', name: 'Fitness', icon: Dumbbell, count: 18, color: 'from-red-500 to-pink-500' },
    { id: 'tech', name: 'Tech Support', icon: Laptop, count: 22, color: 'from-indigo-500 to-purple-500' }
  ];

  const services = [
    {
      id: 1,
      name: 'Premium Car Wash & Detailing',
      provider: 'AutoCare Pro',
      rating: 4.8,
      reviews: 234,
      price: 25,
      originalPrice: 35,
      duration: '45 min',
      image: 'https://images.pexels.com/photos/3354648/pexels-photo-3354648.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      category: 'automotive',
      location: '2.3 km away',
      verified: true,
      features: ['Exterior wash', 'Interior cleaning', 'Wax coating', 'Tire shine'],
      availability: 'Available today',
      badge: 'Popular',
      discount: 29,
      fastService: true,
      providerImage: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: 2,
      name: 'Deep House Cleaning Service',
      provider: 'CleanPro Services',
      rating: 4.9,
      reviews: 156,
      price: 80,
      originalPrice: 100,
      duration: '2 hours',
      image: 'https://images.pexels.com/photos/4239146/pexels-photo-4239146.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      category: 'home',
      location: '1.8 km away',
      verified: true,
      features: ['Deep cleaning', 'Eco-friendly products', 'Insured staff', 'Equipment included'],
      availability: 'Available tomorrow',
      badge: 'Top Rated',
      discount: 20,
      fastService: false,
      providerImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: 3,
      name: 'AC Repair & Maintenance',
      provider: 'CoolTech Experts',
      rating: 4.7,
      reviews: 89,
      price: 120,
      originalPrice: 150,
      duration: '1.5 hours',
      image: 'https://images.pexels.com/photos/8005394/pexels-photo-8005394.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      category: 'repair',
      location: '3.1 km away',
      verified: true,
      features: ['Gas refill', 'Filter cleaning', '6-month warranty', 'Emergency service'],
      availability: 'Available today',
      badge: 'Certified',
      discount: 20,
      fastService: true,
      providerImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: 4,
      name: 'Premium Hair Styling & Cut',
      provider: 'Style Studio Elite',
      rating: 4.6,
      reviews: 178,
      price: 35,
      originalPrice: 50,
      duration: '1 hour',
      image: 'https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      category: 'beauty',
      location: '0.9 km away',
      verified: true,
      features: ['Professional styling', 'Hair wash included', 'Consultation', 'Premium products'],
      availability: 'Available today',
      badge: 'Trending',
      discount: 30,
      fastService: false,
      providerImage: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: 5,
      name: 'Express Food Delivery',
      provider: 'QuickBites Express',
      rating: 4.5,
      reviews: 312,
      price: 5,
      originalPrice: 8,
      duration: '30 min',
      image: 'https://images.pexels.com/photos/4393021/pexels-photo-4393021.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      category: 'delivery',
      location: 'City-wide',
      verified: true,
      features: ['Fast delivery', 'Hot food guarantee', 'Live tracking', 'Multiple restaurants'],
      availability: 'Available now',
      badge: 'Fast',
      discount: 38,
      fastService: true,
      providerImage: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    },
    {
      id: 6,
      name: 'Emergency Plumbing Service',
      provider: 'FixIt Plumbers Pro',
      rating: 4.8,
      reviews: 145,
      price: 90,
      originalPrice: 120,
      duration: '1 hour',
      image: 'https://images.pexels.com/photos/8005404/pexels-photo-8005404.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      category: 'repair',
      location: '2.7 km away',
      verified: true,
      features: ['Emergency service', 'Licensed plumber', 'Parts included', '24/7 available'],
      availability: '24/7 available',
      badge: 'Emergency',
      discount: 25,
      fastService: true,
      providerImage: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop'
    }
  ];

  const upcomingBookings = [
    {
      id: 1,
      service: 'Car Wash & Detailing',
      provider: 'AutoCare Pro',
      date: 'Today',
      time: '2:00 PM',
      status: 'confirmed',
      image: 'https://images.pexels.com/photos/3354648/pexels-photo-3354648.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop',
      price: '$25'
    },
    {
      id: 2,
      service: 'House Cleaning',
      provider: 'CleanPro Services',
      date: 'Tomorrow',
      time: '10:00 AM',
      status: 'pending',
      image: 'https://images.pexels.com/photos/4239146/pexels-photo-4239146.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop',
      price: '$80'
    },
    {
      id: 3,
      service: 'Hair Styling',
      provider: 'Style Studio',
      date: 'Friday',
      time: '3:30 PM',
      status: 'confirmed',
      image: 'https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&fit=crop',
      price: '$35'
    }
  ];

  const timeSlots = [
    '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM',
    '5:00 PM', '6:00 PM', '7:00 PM', '8:00 PM'
  ];

  const getBadgeColor = (badge) => {
    switch (badge) {
      case 'Popular': return 'bg-gradient-to-r from-blue-500 to-indigo-500';
      case 'Top Rated': return 'bg-gradient-to-r from-green-500 to-emerald-500';
      case 'Certified': return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'Trending': return 'bg-gradient-to-r from-orange-500 to-red-500';
      case 'Fast': return 'bg-gradient-to-r from-cyan-500 to-blue-500';
      case 'Emergency': return 'bg-gradient-to-r from-red-500 to-pink-500';
      default: return 'bg-gradient-to-r from-gray-500 to-gray-600';
    }
  };

  const filteredServices = selectedCategory === 'all' 
    ? services 
    : services.filter(service => service.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Enhanced Header */}
      <div className="bg-white/90 backdrop-blur-xl border-b border-gray-200/50 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Service Booking</h1>
              <p className="text-gray-600 mt-1">Book trusted services from verified providers near you</p>
            </div>

            {/* Enhanced Search */}
            <div className="flex-1 max-w-md">
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-blue-500 transition-colors" />
                <input
                  type="text"
                  placeholder="Search services, providers..."
                  className="w-full pl-12 pr-6 py-3 bg-gray-50/80 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all duration-200"
                />
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                  <kbd className="px-2 py-1 text-xs text-gray-500 bg-gray-200 rounded-md">⌘K</kbd>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-gray-100 rounded-2xl p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-3 rounded-xl transition-all duration-200 ${
                    viewMode === 'grid' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-600'
                  }`}
                >
                  <Grid3X3 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-3 rounded-xl transition-all duration-200 ${
                    viewMode === 'list' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
              
              <button className="flex items-center space-x-2 px-6 py-3 border border-gray-300 rounded-2xl hover:bg-gray-50 transition-colors bg-white">
                <SlidersHorizontal className="w-4 h-4" />
                <span className="font-medium">Filters</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Enhanced Sidebar */}
          <aside className="lg:w-80">
            {/* Categories */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6 mb-6">
              <h3 className="font-bold text-gray-900 mb-6 text-lg">Service Categories</h3>
              <div className="space-y-3">
                {categories.map((category) => {
                  const Icon = category.icon;
                  const isActive = selectedCategory === category.id;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full flex items-center space-x-4 px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
                        isActive
                          ? `bg-gradient-to-r ${category.color} text-white shadow-lg`
                          : 'text-gray-600 hover:bg-gray-50 hover:text-blue-600'
                      }`}
                    >
                      <div className={`p-2 rounded-lg transition-all duration-200 ${
                        isActive ? 'bg-white/20' : 'bg-gray-100 group-hover:bg-blue-100'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <span className="font-medium">{category.name}</span>
                        <p className={`text-xs mt-0.5 ${isActive ? 'text-white/80' : 'text-gray-500'}`}>
                          {category.count} services
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Booking */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6 mb-6">
              <h3 className="font-bold text-gray-900 mb-6 text-lg">Quick Booking</h3>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">Select Date</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">Select Time</label>
                  <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                    {timeSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`px-3 py-2 text-sm rounded-xl border transition-all duration-200 ${
                          selectedTime === time
                            ? 'bg-blue-600 text-white border-blue-600 shadow-lg'
                            : 'bg-white text-gray-700 border-gray-300 hover:border-blue-300 hover:bg-blue-50'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                <button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                  Find Available Services
                </button>
              </div>
            </div>

            {/* Upcoming Bookings */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 p-6">
              <h3 className="font-bold text-gray-900 mb-6 text-lg">Upcoming Bookings</h3>
              <div className="space-y-4">
                {upcomingBookings.map((booking) => (
                  <div key={booking.id} className="flex items-center space-x-4 p-4 bg-gray-50/80 rounded-xl hover:bg-blue-50/80 transition-colors group">
                    <img
                      src={booking.image}
                      alt={booking.service}
                      className="w-14 h-14 rounded-xl object-cover shadow-sm"
                    />
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                        {booking.service}
                      </p>
                      <p className="text-sm text-gray-600">{booking.provider}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Calendar className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-500">{booking.date} at {booking.time}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gray-900">{booking.price}</p>
                      <div className={`w-2 h-2 rounded-full mt-1 ${
                        booking.status === 'confirmed' ? 'bg-green-500' : 'bg-yellow-500'
                      }`}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </aside>

          {/* Enhanced Main Content */}
          <main className="flex-1">
            {/* Stats Bar */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-6">
                <span className="text-gray-600">
                  Showing <span className="font-semibold text-gray-900">1-6</span> of <span className="font-semibold text-gray-900">{filteredServices.length}</span> services
                </span>
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-green-600 font-medium">Instant booking available</span>
                </div>
              </div>
              
              <select className="border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white">
                <option>Sort by: Featured</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Rating: Highest</option>
                <option>Distance: Nearest</option>
                <option>Availability: Soonest</option>
              </select>
            </div>

            {/* Enhanced Services Grid */}
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 md:grid-cols-2' 
                : 'grid-cols-1'
            }`}>
              {filteredServices.map((service) => (
                <div key={service.id} className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-gray-200/50 overflow-hidden hover:shadow-xl transition-all duration-300 group hover:scale-105">
                  {/* Service Image */}
                  <div className="relative h-56">
                    <img
                      src={service.image}
                      alt={service.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    
                    {/* Badges */}
                    <div className="absolute top-4 left-4 flex flex-col space-y-2">
                      <div className={`${getBadgeColor(service.badge)} text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg`}>
                        {service.badge}
                      </div>
                      {service.discount > 0 && (
                        <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg">
                          -{service.discount}% OFF
                        </div>
                      )}
                    </div>

                    {/* Quick Actions */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-3">
                      <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg">
                        <Eye className="w-5 h-5" />
                      </button>
                      <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg">
                        <Heart className="w-5 h-5" />
                      </button>
                      <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg">
                        <Share2 className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Status Indicators */}
                    <div className="absolute top-4 right-4 flex flex-col space-y-2">
                      {service.fastService && (
                        <div className="bg-green-500 text-white p-2 rounded-full shadow-lg">
                          <Zap className="w-3 h-3" />
                        </div>
                      )}
                      {service.verified && (
                        <div className="bg-blue-500 text-white p-2 rounded-full shadow-lg">
                          <Shield className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Enhanced Service Info */}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="font-bold text-gray-900 text-xl line-clamp-2">{service.name}</h3>
                      <button className="text-gray-400 hover:text-red-500 transition-colors">
                        <Heart className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Provider Info */}
                    <div className="flex items-center space-x-3 mb-4">
                      <img
                        src={service.providerImage}
                        alt={service.provider}
                        className="w-10 h-10 rounded-xl object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-semibold text-blue-600 hover:text-blue-700 cursor-pointer">
                            {service.provider}
                          </span>
                          {service.verified && (
                            <Shield className="w-3 h-3 text-green-500" />
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                          <span className="text-xs text-gray-600">{service.rating} ({service.reviews} reviews)</span>
                        </div>
                      </div>
                    </div>

                    {/* Location and Duration */}
                    <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3" />
                        <span>{service.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{service.duration}</span>
                      </div>
                    </div>

                    {/* Features */}
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-2">
                        {service.features.slice(0, 3).map((feature, index) => (
                          <span key={index} className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-medium">
                            {feature}
                          </span>
                        ))}
                        {service.features.length > 3 && (
                          <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-medium">
                            +{service.features.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Price */}
                    <div className="flex items-center space-x-3 mb-4">
                      <span className="text-3xl font-bold text-gray-900">${service.price}</span>
                      {service.originalPrice > service.price && (
                        <span className="text-lg text-gray-500 line-through">${service.originalPrice}</span>
                      )}
                      {service.discount > 0 && (
                        <span className="bg-green-100 text-green-600 px-2 py-1 rounded-full text-xs font-semibold">
                          Save ${service.originalPrice - service.price}
                        </span>
                      )}
                    </div>

                    {/* Availability */}
                    <div className="flex items-center space-x-2 mb-6">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-sm text-green-600 font-medium">{service.availability}</span>
                      {service.fastService && (
                        <>
                          <span className="text-gray-300">•</span>
                          <span className="text-sm text-blue-600 font-medium">Fast Service</span>
                        </>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex space-x-3">
                      <button className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-4 rounded-xl hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2 font-semibold">
                        <Calendar className="w-4 h-4" />
                        <span>Book Now</span>
                      </button>
                      <button className="border border-gray-300 text-gray-700 py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors">
                        <Phone className="w-4 h-4" />
                      </button>
                      <button className="border border-gray-300 text-gray-700 py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Enhanced Load More */}
            <div className="text-center mt-12">
              <button className="bg-white border border-gray-300 text-gray-700 px-8 py-4 rounded-2xl hover:bg-gray-50 transition-all duration-200 flex items-center space-x-3 mx-auto shadow-sm hover:shadow-md">
                <span className="font-medium">Load More Services</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}