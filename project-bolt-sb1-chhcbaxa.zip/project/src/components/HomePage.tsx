import React, { useState } from 'react';
import { 
  ArrowRight, 
  Star, 
  Users, 
  Shield, 
  Zap, 
  TrendingUp,
  MessageCircle,
  ShoppingBag,
  CreditCard,
  Calendar,
  Globe,
  Award,
  Clock,
  MapPin,
  Play,
  ChevronRight,
  Sparkles,
  Target,
  Rocket,
  Heart,
  Eye,
  Share2,
  Plus,
  Filter,
  Search
} from 'lucide-react';

export default function HomePage() {
  const [activeFeature, setActiveFeature] = useState(0);

  const features = [
    {
      icon: ShoppingBag,
      title: 'Smart Marketplace',
      description: 'Discover amazing products with AI-powered recommendations',
      color: 'from-purple-500 to-pink-500',
      stats: '500K+ products',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
    },
    {
      icon: MessageCircle,
      title: 'Instant Connect',
      description: 'Chat with friends, businesses, and service providers',
      color: 'from-green-500 to-emerald-500',
      stats: '2M+ messages daily',
      image: 'https://images.pexels.com/photos/1591061/pexels-photo-1591061.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
    },
    {
      icon: CreditCard,
      title: 'Secure Payments',
      description: 'Lightning-fast transactions with bank-level security',
      color: 'from-blue-500 to-cyan-500',
      stats: '$50M+ processed',
      image: 'https://images.pexels.com/photos/4386431/pexels-photo-4386431.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
    },
    {
      icon: Calendar,
      title: 'Service Booking',
      description: 'Book trusted services from verified providers',
      color: 'from-orange-500 to-red-500',
      stats: '100K+ bookings',
      image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
    }
  ];

  const stats = [
    { label: 'Active Users', value: '10M+', icon: Users, color: 'from-blue-500 to-indigo-500' },
    { label: 'Transactions', value: '$2.5B+', icon: TrendingUp, color: 'from-green-500 to-emerald-500' },
    { label: 'Countries', value: '50+', icon: Globe, color: 'from-purple-500 to-pink-500' },
    { label: 'Rating', value: '4.9★', icon: Star, color: 'from-yellow-500 to-orange-500' }
  ];

  const recentActivity = [
    { 
      type: 'payment', 
      title: 'Payment to Sarah Johnson', 
      amount: '$45.00', 
      time: '2 min ago', 
      icon: CreditCard,
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      status: 'completed'
    },
    { 
      type: 'message', 
      title: 'New message from TechStore', 
      amount: '', 
      time: '5 min ago', 
      icon: MessageCircle,
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      status: 'unread'
    },
    { 
      type: 'booking', 
      title: 'Car wash scheduled', 
      amount: '$25.00', 
      time: '1 hour ago', 
      icon: Calendar,
      avatar: 'https://images.pexels.com/photos/3354648/pexels-photo-3354648.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      status: 'confirmed'
    },
    { 
      type: 'purchase', 
      title: 'iPhone case delivered', 
      amount: '$29.99', 
      time: '3 hours ago', 
      icon: ShoppingBag,
      avatar: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      status: 'delivered'
    }
  ];

  const quickActions = [
    { icon: CreditCard, label: 'Send Money', color: 'from-blue-500 to-indigo-500', description: 'Transfer funds instantly' },
    { icon: Calendar, label: 'Book Service', color: 'from-green-500 to-emerald-500', description: 'Find trusted providers' },
    { icon: ShoppingBag, label: 'Shop Now', color: 'from-purple-500 to-pink-500', description: 'Discover great deals' },
    { icon: MessageCircle, label: 'Start Chat', color: 'from-orange-500 to-red-500', description: 'Connect instantly' }
  ];

  const trendingProducts = [
    {
      id: 1,
      name: 'iPhone 15 Pro',
      price: '$999',
      image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
      rating: 4.8,
      discount: '10% OFF'
    },
    {
      id: 2,
      name: 'MacBook Air',
      price: '$1,199',
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
      rating: 4.9,
      discount: '5% OFF'
    },
    {
      id: 3,
      name: 'AirPods Pro',
      price: '$249',
      image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
      rating: 4.7,
      discount: '15% OFF'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Enhanced Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600"></div>
        <div className="absolute inset-0 bg-black/10"></div>
        
        {/* Animated Background Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-white/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-purple-400/20 rounded-full blur-xl animate-bounce"></div>
        <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-cyan-400/15 rounded-full blur-xl animate-ping"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span className="text-white text-sm font-medium">New Features Available</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Everything You Need
              <span className="block bg-gradient-to-r from-yellow-300 via-orange-300 to-pink-300 bg-clip-text text-transparent">
                In One Place
              </span>
            </h1>
            
            <p className="text-xl text-blue-100 mb-10 max-w-3xl mx-auto leading-relaxed">
              Shop, chat, pay, and book services seamlessly. Experience the future of digital lifestyle with our revolutionary super app.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button className="group bg-white text-blue-600 px-8 py-4 rounded-2xl font-semibold hover:bg-blue-50 transition-all duration-300 flex items-center justify-center space-x-3 shadow-xl hover:shadow-2xl hover:scale-105">
                <Rocket className="w-5 h-5 group-hover:animate-bounce" />
                <span>Get Started Free</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="group border-2 border-white text-white px-8 py-4 rounded-2xl font-semibold hover:bg-white hover:text-blue-600 transition-all duration-300 flex items-center justify-center space-x-3">
                <Play className="w-5 h-5" />
                <span>Watch Demo</span>
              </button>
            </div>

            {/* Feature Preview Cards */}
            <div className="grid md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div 
                    key={index}
                    className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 hover:bg-white/20 transition-all duration-300 cursor-pointer group"
                    onClick={() => setActiveFeature(index)}
                  >
                    <div className={`w-12 h-12 bg-gradient-to-r ${feature.color} rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-white font-semibold mb-1">{feature.title}</h3>
                    <p className="text-blue-100 text-sm">{feature.stats}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Stats Section */}
      <section className="py-20 bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Trusted by Millions</h2>
            <p className="text-gray-600">Join the growing community of satisfied users</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center group">
                  <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r ${stat.color} rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-4xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600 font-medium">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Enhanced Features Showcase */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Powerful Features
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need to manage your digital life efficiently
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Feature Image */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src={features[activeFeature].image}
                  alt={features[activeFeature].title}
                  className="w-full h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute bottom-6 left-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">{features[activeFeature].title}</h3>
                  <p className="text-white/90">{features[activeFeature].description}</p>
                </div>
              </div>
            </div>

            {/* Feature List */}
            <div className="space-y-4">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                const isActive = activeFeature === index;
                return (
                  <div
                    key={index}
                    className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 ${
                      isActive 
                        ? `bg-gradient-to-r ${feature.color} text-white shadow-lg scale-105` 
                        : 'bg-white hover:bg-gray-50 border border-gray-200'
                    }`}
                    onClick={() => setActiveFeature(index)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        isActive ? 'bg-white/20' : 'bg-gray-100'
                      }`}>
                        <Icon className={`w-6 h-6 ${isActive ? 'text-white' : 'text-gray-600'}`} />
                      </div>
                      <div className="flex-1">
                        <h3 className={`text-xl font-bold mb-1 ${isActive ? 'text-white' : 'text-gray-900'}`}>
                          {feature.title}
                        </h3>
                        <p className={`${isActive ? 'text-white/90' : 'text-gray-600'}`}>
                          {feature.description}
                        </p>
                        <div className={`text-sm font-semibold mt-2 ${isActive ? 'text-white/80' : 'text-blue-600'}`}>
                          {feature.stats}
                        </div>
                      </div>
                      <ChevronRight className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-400'}`} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Dashboard Preview */}
      <section className="py-20 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900">Recent Activity</h3>
                <button className="text-blue-600 hover:text-blue-700 font-medium flex items-center space-x-1">
                  <span>View All</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
              
              <div className="space-y-4">
                {recentActivity.map((activity, index) => {
                  const Icon = activity.icon;
                  return (
                    <div key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300 group">
                      <div className="flex items-center space-x-4">
                        <div className="relative">
                          <img
                            src={activity.avatar}
                            alt=""
                            className="w-12 h-12 rounded-xl object-cover"
                          />
                          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-lg flex items-center justify-center">
                            <Icon className="w-3 h-3 text-white" />
                          </div>
                        </div>
                        
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {activity.title}
                          </p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="w-3 h-3 text-gray-400" />
                            <span className="text-sm text-gray-500">{activity.time}</span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              activity.status === 'completed' ? 'bg-green-100 text-green-600' :
                              activity.status === 'confirmed' ? 'bg-blue-100 text-blue-600' :
                              activity.status === 'delivered' ? 'bg-purple-100 text-purple-600' :
                              'bg-orange-100 text-orange-600'
                            }`}>
                              {activity.status}
                            </span>
                          </div>
                        </div>
                        
                        {activity.amount && (
                          <div className="text-right">
                            <p className="font-bold text-gray-900">{activity.amount}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Actions & Trending */}
            <div className="space-y-8">
              {/* Quick Actions */}
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h3>
                <div className="space-y-3">
                  {quickActions.map((action, index) => {
                    const Icon = action.icon;
                    return (
                      <button
                        key={index}
                        className={`w-full bg-gradient-to-r ${action.color} text-white p-4 rounded-2xl font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105 group`}
                      >
                        <div className="flex items-center space-x-3">
                          <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                          <div className="text-left">
                            <div className="font-semibold">{action.label}</div>
                            <div className="text-xs text-white/80">{action.description}</div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Trending Products */}
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Trending Now</h3>
                <div className="space-y-4">
                  {trendingProducts.map((product) => (
                    <div key={product.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300 group">
                      <div className="flex items-center space-x-3">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-16 h-16 rounded-xl object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {product.name}
                          </h4>
                          <div className="flex items-center space-x-2 mt-1">
                            <Star className="w-3 h-3 text-yellow-400 fill-current" />
                            <span className="text-sm text-gray-600">{product.rating}</span>
                            <span className="bg-red-100 text-red-600 px-2 py-1 rounded-full text-xs font-medium">
                              {product.discount}
                            </span>
                          </div>
                          <p className="font-bold text-gray-900 mt-1">{product.price}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Security Badge */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Shield className="w-8 h-8 text-green-600" />
                  <span className="font-bold text-green-800">Bank-Level Security</span>
                </div>
                <p className="text-sm text-green-700 leading-relaxed">
                  Your data and transactions are protected with enterprise-grade encryption, multi-factor authentication, and real-time fraud monitoring.
                </p>
                <div className="flex items-center space-x-4 mt-4">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-xs text-green-600">SSL Encrypted</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-xs text-green-600">PCI Compliant</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}