import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  MoreVertical, 
  Phone, 
  Video, 
  Send,
  Smile,
  Paperclip,
  Users,
  Star,
  Clock,
  CheckCheck,
  Circle,
  Image,
  Mic,
  Camera,
  MapPin,
  Gift,
  Archive,
  Pin,
  Trash2,
  Edit3,
  Filter,
  Settings
} from 'lucide-react';

export default function ChatSection() {
  const [selectedChat, setSelectedChat] = useState(0);
  const [message, setMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const chats = [
    {
      id: 1,
      name: 'Sarah Johnson',
      lastMessage: 'Hey! How are you doing? 😊',
      time: '2 min',
      unread: 2,
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      online: true,
      type: 'personal',
      isPinned: true,
      lastSeen: 'Online'
    },
    {
      id: 2,
      name: 'TechStore Support',
      lastMessage: 'Your order #12345 has been shipped! 📦',
      time: '1 hour',
      unread: 0,
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      online: false,
      type: 'business',
      isPinned: false,
      lastSeen: '2 hours ago'
    },
    {
      id: 3,
      name: 'Family Group',
      lastMessage: 'Mom: Dinner at 7 PM tonight! 🍽️',
      time: '3 hours',
      unread: 5,
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      online: true,
      type: 'group',
      isPinned: true,
      lastSeen: '3 members online'
    },
    {
      id: 4,
      name: 'John Smith',
      lastMessage: 'Thanks for the help with the project! 🙏',
      time: '1 day',
      unread: 0,
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      online: false,
      type: 'personal',
      isPinned: false,
      lastSeen: 'Yesterday'
    },
    {
      id: 5,
      name: 'Design Team',
      lastMessage: 'Alex: New mockups are ready for review ✨',
      time: '2 days',
      unread: 12,
      avatar: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      online: true,
      type: 'group',
      isPinned: false,
      lastSeen: '5 members online'
    }
  ];

  const messages = [
    {
      id: 1,
      sender: 'Sarah Johnson',
      content: 'Hey! How are you doing? 😊',
      time: '2:30 PM',
      isOwn: false,
      status: 'read',
      type: 'text'
    },
    {
      id: 2,
      sender: 'You',
      content: 'I\'m doing great! Just working on some exciting new projects. How about you?',
      time: '2:32 PM',
      isOwn: true,
      status: 'read',
      type: 'text'
    },
    {
      id: 3,
      sender: 'Sarah Johnson',
      content: 'That sounds amazing! I\'d love to hear more about it. Are you free for coffee this weekend?',
      time: '2:33 PM',
      isOwn: false,
      status: 'read',
      type: 'text'
    },
    {
      id: 4,
      sender: 'You',
      content: 'Absolutely! Let\'s meet at our usual spot on Saturday around 2 PM? ☕',
      time: '2:35 PM',
      isOwn: true,
      status: 'delivered',
      type: 'text'
    },
    {
      id: 5,
      sender: 'Sarah Johnson',
      content: 'Perfect! See you there! 🎉',
      time: '2:36 PM',
      isOwn: false,
      status: 'read',
      type: 'text'
    }
  ];

  const quickReplies = ['👍', '❤️', '😂', '😮', '😢', '😡'];

  const filteredChats = chats.filter(chat =>
    chat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentChat = chats[selectedChat];

  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex">
      {/* Enhanced Chat List */}
      <div className="w-80 bg-white/90 backdrop-blur-xl border-r border-gray-200/50 flex flex-col shadow-lg">
        {/* Enhanced Header */}
        <div className="p-6 border-b border-gray-200/50 bg-white/50">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Messages</h2>
              <p className="text-sm text-gray-500">Stay connected with everyone</p>
            </div>
            <div className="flex items-center space-x-2">
              <button className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl flex items-center justify-center hover:scale-110 transition-transform duration-200 shadow-lg">
                <Plus className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 bg-gray-100 text-gray-600 rounded-xl flex items-center justify-center hover:bg-gray-200 transition-colors">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          {/* Enhanced Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50/80 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all duration-200"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            )}
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center space-x-2 mt-4">
            <button className="px-4 py-2 bg-blue-100 text-blue-600 rounded-xl text-sm font-medium">
              All
            </button>
            <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl text-sm font-medium transition-colors">
              Personal
            </button>
            <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl text-sm font-medium transition-colors">
              Business
            </button>
          </div>
        </div>

        {/* Enhanced Chat List */}
        <div className="flex-1 overflow-y-auto">
          {filteredChats.map((chat, index) => (
            <div
              key={chat.id}
              onClick={() => setSelectedChat(index)}
              className={`p-4 border-b border-gray-100/50 cursor-pointer hover:bg-blue-50/50 transition-all duration-200 group ${
                selectedChat === index ? 'bg-blue-50 border-blue-200/50' : ''
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img
                    src={chat.avatar}
                    alt={chat.name}
                    className="w-14 h-14 rounded-2xl object-cover shadow-sm"
                  />
                  {chat.online && (
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                  )}
                  {chat.isPinned && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                      <Pin className="w-2.5 h-2.5 text-white" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-semibold text-gray-900 truncate">{chat.name}</h3>
                      {chat.type === 'group' && (
                        <Users className="w-3 h-3 text-gray-400" />
                      )}
                      {chat.type === 'business' && (
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      )}
                    </div>
                    <span className="text-xs text-gray-500 font-medium">{chat.time}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-600 truncate pr-2">{chat.lastMessage}</p>
                    {chat.unread > 0 && (
                      <span className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-xs rounded-full px-2.5 py-1 min-w-[20px] text-center font-medium shadow-sm">
                        {chat.unread > 99 ? '99+' : chat.unread}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Enhanced Chat Window */}
      <div className="flex-1 flex flex-col bg-white/50 backdrop-blur-sm">
        {/* Enhanced Chat Header */}
        <div className="p-6 border-b border-gray-200/50 bg-white/80 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <img
                  src={currentChat?.avatar}
                  alt={currentChat?.name}
                  className="w-12 h-12 rounded-2xl object-cover shadow-sm"
                />
                {currentChat?.online && (
                  <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full"></div>
                )}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="font-bold text-gray-900">{currentChat?.name}</h3>
                  {currentChat?.type === 'group' && (
                    <Users className="w-4 h-4 text-gray-400" />
                  )}
                  {currentChat?.type === 'business' && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  )}
                </div>
                <p className="text-sm text-gray-500 flex items-center space-x-1">
                  <Circle className={`w-2 h-2 ${currentChat?.online ? 'text-green-500 fill-current' : 'text-gray-400'}`} />
                  <span>{currentChat?.lastSeen}</span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Phone className="w-5 h-5" />
              </button>
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Video className="w-5 h-5" />
              </button>
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <MoreVertical className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Enhanced Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-gradient-to-b from-blue-50/30 to-indigo-50/30">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs lg:max-w-md ${msg.isOwn ? 'order-2' : 'order-1'}`}>
                <div className={`px-6 py-4 rounded-3xl shadow-sm ${
                  msg.isOwn
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white'
                    : 'bg-white text-gray-900 border border-gray-200/50'
                }`}>
                  <p className="text-sm leading-relaxed">{msg.content}</p>
                </div>
                <div className={`flex items-center justify-end space-x-2 mt-2 px-2 ${
                  msg.isOwn ? 'text-blue-600' : 'text-gray-500'
                }`}>
                  <span className="text-xs font-medium">{msg.time}</span>
                  {msg.isOwn && (
                    <CheckCheck className={`w-4 h-4 ${
                      msg.status === 'read' ? 'text-blue-500' : 'text-gray-400'
                    }`} />
                  )}
                </div>
              </div>
              
              {!msg.isOwn && (
                <div className="order-1 mr-3">
                  <img
                    src={currentChat?.avatar}
                    alt=""
                    className="w-8 h-8 rounded-full object-cover"
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Quick Reactions */}
        <div className="px-6 py-3 border-t border-gray-200/50 bg-white/80">
          <div className="flex items-center space-x-3">
            <span className="text-sm text-gray-500 font-medium">Quick reactions:</span>
            <div className="flex items-center space-x-2">
              {quickReplies.map((emoji, index) => (
                <button
                  key={index}
                  className="w-8 h-8 bg-gray-100 hover:bg-blue-100 rounded-full flex items-center justify-center transition-colors duration-200 text-sm"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Enhanced Message Input */}
        <div className="p-6 border-t border-gray-200/50 bg-white/90 backdrop-blur-xl">
          <div className="flex items-end space-x-4">
            <div className="flex items-center space-x-2">
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Paperclip className="w-5 h-5" />
              </button>
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Image className="w-5 h-5" />
              </button>
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Camera className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex-1 relative">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
                className="w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-3xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all duration-200 pr-12"
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && message.trim()) {
                    setMessage('');
                  }
                }}
              />
              <button 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-600 hover:text-blue-600 transition-colors"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              >
                <Smile className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex items-center space-x-2">
              <button className="p-3 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Mic className="w-5 h-5" />
              </button>
              <button 
                className={`p-4 rounded-2xl transition-all duration-200 ${
                  message.trim() 
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-lg hover:shadow-xl hover:scale-105' 
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
                disabled={!message.trim()}
                onClick={() => {
                  if (message.trim()) {
                    setMessage('');
                  }
                }}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}