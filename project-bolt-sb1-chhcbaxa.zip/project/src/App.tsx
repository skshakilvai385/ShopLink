import React, { useState } from 'react';
import { 
  Home, 
  MessageCircle, 
  ShoppingBag, 
  CreditCard, 
  Calendar,
  Menu,
  X,
  Bell,
  Search,
  User,
  Wallet,
  Star,
  MapPin,
  Clock,
  TrendingUp,
  Shield,
  Zap,
  Settings,
  Heart,
  Grid3X3,
  Plus
} from 'lucide-react';
import HomePage from './components/HomePage';
import ChatSection from './components/ChatSection';
import Marketplace from './components/Marketplace';
import PaymentGateway from './components/PaymentGateway';
import ServiceBooking from './components/ServiceBooking';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notifications] = useState(3);

  const tabs = [
    { id: 'home', label: 'Home', icon: Home, component: HomePage, color: 'from-blue-500 to-indigo-500' },
    { id: 'marketplace', label: 'Shop', icon: ShoppingBag, component: Marketplace, color: 'from-purple-500 to-pink-500' },
    { id: 'chat', label: 'Messages', icon: MessageCircle, component: ChatSection, color: 'from-green-500 to-emerald-500' },
    { id: 'services', label: 'Services', icon: Calendar, component: ServiceBooking, color: 'from-orange-500 to-red-500' },
    { id: 'payments', label: 'Wallet', icon: CreditCard, component: PaymentGateway, color: 'from-cyan-500 to-blue-500' },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component || HomePage;
  const activeTabData = tabs.find(tab => tab.id === activeTab);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Enhanced Header */}
      <header className="bg-white/95 backdrop-blur-xl border-b border-gray-200/50 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Enhanced Logo */}
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-400 rounded-full animate-pulse"></div>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  ShopLink
                </h1>
                <p className="text-xs text-gray-500 font-medium">All-in-One Platform</p>
              </div>
            </div>

            {/* Enhanced Search Bar */}
            <div className="hidden md:flex flex-1 max-w-xl mx-8">
              <div className="relative w-full group">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-blue-500 transition-colors" />
                <input
                  type="text"
                  placeholder="Search products, services, or start a chat..."
                  className="w-full pl-12 pr-6 py-3 bg-gray-50/80 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all duration-200 text-sm"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <kbd className="px-2 py-1 text-xs text-gray-500 bg-gray-200 rounded-md">⌘K</kbd>
                </div>
              </div>
            </div>

            {/* Enhanced Right Actions */}
            <div className="flex items-center space-x-3">
              <button className="relative p-2.5 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200 group">
                <Bell className="w-5 h-5" />
                {notifications > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium animate-bounce">
                    {notifications}
                  </span>
                )}
              </button>
              
              <button className="p-2.5 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200">
                <Heart className="w-5 h-5" />
              </button>
              
              <div className="hidden sm:flex items-center space-x-2 bg-gray-50 rounded-xl p-1">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <span className="text-sm font-medium text-gray-700 px-2">John Doe</span>
              </div>
              
              <button 
                className="md:hidden p-2.5 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Enhanced Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white/95 backdrop-blur-xl border-t border-gray-200/50">
            <div className="px-4 py-4 space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search everything..."
                  className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">John Doe</p>
                    <p className="text-sm text-gray-500">Premium Member</p>
                  </div>
                </div>
                <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                  <Settings className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      <div className="flex">
        {/* Enhanced Sidebar */}
        <aside className="hidden lg:flex flex-col w-72 bg-white/70 backdrop-blur-xl border-r border-gray-200/50 min-h-screen">
          <nav className="flex-1 px-6 py-8 space-y-3">
            <div className="mb-6">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Navigation</h3>
            </div>
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-4 px-4 py-3.5 rounded-2xl text-left transition-all duration-300 group ${
                    isActive
                      ? `bg-gradient-to-r ${tab.color} text-white shadow-lg shadow-blue-500/25 scale-105`
                      : 'text-gray-600 hover:bg-gray-50 hover:text-blue-600 hover:scale-105'
                  }`}
                >
                  <div className={`p-2 rounded-xl transition-all duration-300 ${
                    isActive 
                      ? 'bg-white/20' 
                      : 'bg-gray-100 group-hover:bg-blue-100'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <span className="font-semibold">{tab.label}</span>
                    <p className={`text-xs mt-0.5 ${
                      isActive ? 'text-white/80' : 'text-gray-500'
                    }`}>
                      {tab.id === 'home' && 'Dashboard & Overview'}
                      {tab.id === 'marketplace' && 'Shop & Discover'}
                      {tab.id === 'chat' && 'Connect & Chat'}
                      {tab.id === 'services' && 'Book & Schedule'}
                      {tab.id === 'payments' && 'Pay & Transfer'}
                    </p>
                  </div>
                </button>
              );
            })}
          </nav>

          {/* Enhanced Quick Stats */}
          <div className="p-6 border-t border-gray-200/50">
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-5 border border-green-200/50">
              <div className="flex items-center space-x-3 mb-3">
                <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                  <Wallet className="w-4 h-4 text-white" />
                </div>
                <span className="text-sm font-semibold text-green-800">Wallet Balance</span>
              </div>
              <p className="text-2xl font-bold text-green-600 mb-1">$1,247.50</p>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-3 h-3 text-green-500" />
                <p className="text-xs text-green-600 font-medium">+12.5% this month</p>
              </div>
            </div>
            
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="bg-blue-50 rounded-xl p-3 text-center">
                <p className="text-lg font-bold text-blue-600">156</p>
                <p className="text-xs text-blue-600">Orders</p>
              </div>
              <div className="bg-purple-50 rounded-xl p-3 text-center">
                <p className="text-lg font-bold text-purple-600">4.9</p>
                <p className="text-xs text-purple-600">Rating</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Enhanced Main Content */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full">
            <ActiveComponent />
          </div>
        </main>
      </div>

      {/* Enhanced Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-gray-200/50 z-50 shadow-lg">
        <div className="flex items-center justify-around py-2 px-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center space-y-1 px-3 py-2.5 rounded-2xl transition-all duration-300 ${
                  isActive
                    ? 'text-blue-600 bg-blue-50 scale-110'
                    : 'text-gray-500 hover:text-blue-600 hover:bg-blue-50'
                }`}
              >
                <div className={`p-1.5 rounded-xl transition-all duration-300 ${
                  isActive ? 'bg-blue-100' : ''
                }`}>
                  <Icon className={`w-5 h-5 ${isActive ? 'scale-110' : ''} transition-transform duration-300`} />
                </div>
                <span className="text-xs font-semibold">{tab.label}</span>
                {isActive && (
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-pulse"></div>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Enhanced Floating Action Button */}
      <div className="fixed bottom-20 lg:bottom-8 right-6 z-40">
        <button className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl shadow-xl shadow-blue-500/30 flex items-center justify-center hover:shadow-2xl hover:scale-110 transition-all duration-300 group">
          <Plus className="w-7 h-7 group-hover:rotate-90 transition-transform duration-300" />
        </button>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-green-400 to-emerald-400 rounded-full flex items-center justify-center animate-bounce">
          <span className="text-xs font-bold text-white">!</span>
        </div>
      </div>

      {/* Quick Access Overlay */}
      <div className="hidden lg:block fixed top-1/2 left-0 transform -translate-y-1/2 z-30">
        <div className="bg-white/90 backdrop-blur-xl rounded-r-2xl shadow-lg border border-gray-200/50 p-2 space-y-2">
          <button className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl flex items-center justify-center hover:scale-110 transition-transform duration-200">
            <Grid3X3 className="w-4 h-4" />
          </button>
          <button className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl flex items-center justify-center hover:scale-110 transition-transform duration-200">
            <Star className="w-4 h-4" />
          </button>
          <button className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl flex items-center justify-center hover:scale-110 transition-transform duration-200">
            <Shield className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;