import React, { useState } from 'react';
import { RoleSelection } from './components/RoleSelection';
import { CustomerDashboard } from './components/CustomerDashboard';
import { SellerDashboard } from './components/SellerDashboard';

export type UserRole = 'customer' | 'seller' | null;

function App() {
  const [userRole, setUserRole] = useState<UserRole>(null);

  const handleRoleSelect = (role: 'customer' | 'seller') => {
    setUserRole(role);
  };

  const handleBackToSelection = () => {
    setUserRole(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {userRole === null && (
          <RoleSelection onRoleSelect={handleRoleSelect} />
        )}
        
        {userRole === 'customer' && (
          <CustomerDashboard onBack={handleBackToSelection} />
        )}
        
        {userRole === 'seller' && (
          <SellerDashboard onBack={handleBackToSelection} />
        )}
      </div>
    </div>
  );
}

export default App;