import React from 'react';
import { ShoppingBag, Store, ArrowRight } from 'lucide-react';

interface RoleSelectionProps {
  onRoleSelect: (role: 'customer' | 'seller') => void;
}

export const RoleSelection: React.FC<RoleSelectionProps> = ({ onRoleSelect }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] animate-in fade-in duration-700">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gray-900 mb-4">
          Welcome to <span className="text-indigo-600">MarketPlace</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Choose your role to access your personalized dashboard and start managing your business or shopping experience.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl w-full">
        {/* Customer Role Card */}
        <div 
          onClick={() => onRoleSelect('customer')}
          className="group cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl"
        >
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-200 h-full flex flex-col justify-between">
            <div>
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:shadow-lg transition-shadow duration-300">
                <ShoppingBag className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">I'm a Customer</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Access your orders, track deliveries, manage bookings, and update your profile. 
                Everything you need for a seamless shopping experience.
              </p>
              
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Order Management & Tracking
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Booking History & Scheduling
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Payment History & Receipts
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Profile & Preferences
                </li>
              </ul>
            </div>
            
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
              <span className="text-indigo-600 font-semibold">Enter Customer Portal</span>
              <ArrowRight className="w-5 h-5 text-indigo-600 group-hover:translate-x-1 transition-transform duration-300" />
            </div>
          </div>
        </div>

        {/* Seller Role Card */}
        <div 
          onClick={() => onRoleSelect('seller')}
          className="group cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl"
        >
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-200 h-full flex flex-col justify-between">
            <div>
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mb-6 group-hover:shadow-lg transition-shadow duration-300">
                <Store className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">I'm a Seller</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Manage your products, track sales analytics, handle orders, and grow your business. 
                Complete business management at your fingertips.
              </p>
              
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                  Product & Inventory Management
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                  Sales Analytics & Reports
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                  Order Processing & Fulfillment
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                  Revenue & Payment Tracking
                </li>
              </ul>
            </div>
            
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
              <span className="text-purple-600 font-semibold">Enter Seller Portal</span>
              <ArrowRight className="w-5 h-5 text-purple-600 group-hover:translate-x-1 transition-transform duration-300" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};