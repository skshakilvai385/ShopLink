import React from 'react';
import { 
  Plus, 
  Package, 
  ShoppingCart, 
  BarChart3, 
  Tag, 
  Wallet, 
  Calendar,
  ArrowLeft,
  DollarSign,
  TrendingUp,
  Users
} from 'lucide-react';

interface SellerDashboardProps {
  onBack: () => void;
}

const menuItems = [
  {
    icon: Plus,
    title: 'Add New Product',
    description: 'List new products in your store',
    color: 'from-green-500 to-emerald-600',
    stats: 'Quick Add'
  },
  {
    icon: Package,
    title: 'Product Management',
    description: 'Edit and manage your product catalog',
    color: 'from-blue-500 to-blue-600',
    stats: '47 Products'
  },
  {
    icon: ShoppingCart,
    title: 'Order Management',
    description: 'Process and fulfill customer orders',
    color: 'from-orange-500 to-red-500',
    stats: '23 Pending'
  },
  {
    icon: BarChart3,
    title: 'Sales Analytics',
    description: 'Track performance and growth metrics',
    color: 'from-purple-500 to-pink-600',
    stats: '+15.3%'
  },
  {
    icon: Tag,
    title: 'Promotions',
    description: 'Create discounts and special offers',
    color: 'from-indigo-500 to-purple-600',
    stats: '3 Active'
  },
  {
    icon: Wallet,
    title: 'Financial Reports',
    description: 'Revenue tracking and payment logs',
    color: 'from-teal-500 to-cyan-600',
    stats: '$8,247.30'
  },
  {
    icon: Calendar,
    title: 'Service Bookings',
    description: 'Manage appointments and schedules',
    color: 'from-rose-500 to-pink-600',
    stats: '12 Today'
  }
];

export const SellerDashboard: React.FC<SellerDashboardProps> = ({ onBack }) => {
  return (
    <div className="animate-in slide-in-from-left duration-500">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 p-2 rounded-full hover:bg-white/80 transition-colors duration-200"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Seller Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage your business and grow your sales</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center space-x-4">
          <div className="text-right">
            <p className="text-sm text-gray-500">Monthly Revenue</p>
            <p className="text-2xl font-bold text-green-600">$8,247.30</p>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
              <p className="text-2xl font-bold text-green-600">$8,247</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <div className="flex items-center mt-3 text-sm">
            <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
            <span className="text-green-600">+12.5%</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Orders</p>
              <p className="text-2xl font-bold text-blue-600">156</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          <div className="flex items-center mt-3 text-sm">
            <span className="text-blue-600">23 pending</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Products</p>
              <p className="text-2xl font-bold text-purple-600">47</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
              <Package className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <div className="flex items-center mt-3 text-sm">
            <span className="text-purple-600">5 low stock</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Customers</p>
              <p className="text-2xl font-bold text-orange-600">89</p>
            </div>
            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
              <Users className="w-5 h-5 text-orange-600" />
            </div>
          </div>
          <div className="flex items-center mt-3 text-sm">
            <span className="text-orange-600">+7 this week</span>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menuItems.map((item, index) => (
          <div
            key={index}
            className="group bg-white rounded-xl p-6 shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-105"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 bg-gradient-to-r ${item.color} rounded-xl flex items-center justify-center group-hover:shadow-lg transition-shadow duration-300`}>
                <item.icon className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-semibold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                {item.stats}
              </span>
            </div>
            
            <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-700 transition-colors duration-200">
              {item.title}
            </h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              {item.description}
            </p>
            
            <div className="mt-4 pt-4 border-t border-gray-100">
              <span className="text-sm text-indigo-600 font-medium group-hover:text-indigo-700 transition-colors duration-200">
                Manage →
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};