import React from 'react';
import { 
  ShoppingBag, 
  Package, 
  Calendar, 
  CreditCard, 
  User, 
  ArrowLeft,
  TrendingUp,
  Clock,
  CheckCircle
} from 'lucide-react';

interface CustomerDashboardProps {
  onBack: () => void;
}

const menuItems = [
  {
    icon: ShoppingBag,
    title: 'My Orders',
    description: 'View and manage all your orders',
    color: 'from-blue-500 to-blue-600',
    stats: '12 Active'
  },
  {
    icon: Package,
    title: 'Order Tracking',
    description: 'Track your shipments in real-time',
    color: 'from-green-500 to-emerald-600',
    stats: '3 In Transit'
  },
  {
    icon: Calendar,
    title: 'Booking History',
    description: 'View past and upcoming bookings',
    color: 'from-purple-500 to-purple-600',
    stats: '8 Completed'
  },
  {
    icon: CreditCard,
    title: 'Payment Logs',
    description: 'Transaction history and receipts',
    color: 'from-orange-500 to-red-500',
    stats: '$2,459.20'
  },
  {
    icon: User,
    title: 'Edit Profile',
    description: 'Update your personal information',
    color: 'from-indigo-500 to-purple-600',
    stats: '95% Complete'
  }
];

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({ onBack }) => {
  return (
    <div className="animate-in slide-in-from-right duration-500">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 p-2 rounded-full hover:bg-white/80 transition-colors duration-200"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Customer Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back! Manage your orders and profile</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center space-x-4">
          <div className="text-right">
            <p className="text-sm text-gray-500">Total Spent</p>
            <p className="text-2xl font-bold text-green-600">$2,459.20</p>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Active Orders</p>
              <p className="text-3xl font-bold text-blue-600">12</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="text-green-600 flex items-center">
              <CheckCircle className="w-4 h-4 mr-1" />
              +3 this week
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">In Transit</p>
              <p className="text-3xl font-bold text-orange-600">3</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="text-gray-600">Expected by Friday</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 mb-1">Saved</p>
              <p className="text-3xl font-bold text-green-600">$127.50</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="text-green-600">This month</span>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menuItems.map((item, index) => (
          <div
            key={index}
            className="group bg-white rounded-xl p-6 shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-105"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 bg-gradient-to-r ${item.color} rounded-xl flex items-center justify-center group-hover:shadow-lg transition-shadow duration-300`}>
                <item.icon className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-semibold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                {item.stats}
              </span>
            </div>
            
            <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-700 transition-colors duration-200">
              {item.title}
            </h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              {item.description}
            </p>
            
            <div className="mt-4 pt-4 border-t border-gray-100">
              <span className="text-sm text-indigo-600 font-medium group-hover:text-indigo-700 transition-colors duration-200">
                View Details →
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};